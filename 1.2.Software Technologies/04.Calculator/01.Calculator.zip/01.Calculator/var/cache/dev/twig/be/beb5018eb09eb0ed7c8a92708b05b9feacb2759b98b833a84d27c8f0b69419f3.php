<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_81551cfdd1a89a2e74796f25a5c2c9aac524c436186cf5f9d8d3508b7cc0962e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_80210ca172f776ff0dc517a8fbd4dab0aad9b8dbb65ad5c4319ca738ecd72ea3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_80210ca172f776ff0dc517a8fbd4dab0aad9b8dbb65ad5c4319ca738ecd72ea3->enter($__internal_80210ca172f776ff0dc517a8fbd4dab0aad9b8dbb65ad5c4319ca738ecd72ea3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_80210ca172f776ff0dc517a8fbd4dab0aad9b8dbb65ad5c4319ca738ecd72ea3->leave($__internal_80210ca172f776ff0dc517a8fbd4dab0aad9b8dbb65ad5c4319ca738ecd72ea3_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_81a0d062bee8b7b742d240110903e5b9e987affd91ce07e25dc38ca7b1fd97ed = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81a0d062bee8b7b742d240110903e5b9e987affd91ce07e25dc38ca7b1fd97ed->enter($__internal_81a0d062bee8b7b742d240110903e5b9e987affd91ce07e25dc38ca7b1fd97ed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_81a0d062bee8b7b742d240110903e5b9e987affd91ce07e25dc38ca7b1fd97ed->leave($__internal_81a0d062bee8b7b742d240110903e5b9e987affd91ce07e25dc38ca7b1fd97ed_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_447387b147451fc7e078e0a687883bc5910a17bdb64abe2c9c4587144edc7ab9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_447387b147451fc7e078e0a687883bc5910a17bdb64abe2c9c4587144edc7ab9->enter($__internal_447387b147451fc7e078e0a687883bc5910a17bdb64abe2c9c4587144edc7ab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_447387b147451fc7e078e0a687883bc5910a17bdb64abe2c9c4587144edc7ab9->leave($__internal_447387b147451fc7e078e0a687883bc5910a17bdb64abe2c9c4587144edc7ab9_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ecd3c55b193570fc3150cf41933e12fd41661a67fd9267a5e1ef9e7f8a85f7fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ecd3c55b193570fc3150cf41933e12fd41661a67fd9267a5e1ef9e7f8a85f7fc->enter($__internal_ecd3c55b193570fc3150cf41933e12fd41661a67fd9267a5e1ef9e7f8a85f7fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_ecd3c55b193570fc3150cf41933e12fd41661a67fd9267a5e1ef9e7f8a85f7fc->leave($__internal_ecd3c55b193570fc3150cf41933e12fd41661a67fd9267a5e1ef9e7f8a85f7fc_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 33,  114 => 32,  108 => 28,  106 => 27,  102 => 25,  96 => 24,  88 => 21,  82 => 17,  80 => 16,  75 => 14,  70 => 13,  64 => 12,  54 => 9,  48 => 6,  45 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
";
    }
}

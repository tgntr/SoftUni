<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_b54363f4341c9529bd326b3bf9e769e0af13c8a4af4dea72a9e7da831b55f4dc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2afaf995a8d963aceba3c0676c7bcb1d21895b14a33252ad65566165a8a22e5a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2afaf995a8d963aceba3c0676c7bcb1d21895b14a33252ad65566165a8a22e5a->enter($__internal_2afaf995a8d963aceba3c0676c7bcb1d21895b14a33252ad65566165a8a22e5a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_2afaf995a8d963aceba3c0676c7bcb1d21895b14a33252ad65566165a8a22e5a->leave($__internal_2afaf995a8d963aceba3c0676c7bcb1d21895b14a33252ad65566165a8a22e5a_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_6e8828a5bb8f4fb8004ad114ad2e6ae554418014e5ddc9b9c22a135cbc863ab0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6e8828a5bb8f4fb8004ad114ad2e6ae554418014e5ddc9b9c22a135cbc863ab0->enter($__internal_6e8828a5bb8f4fb8004ad114ad2e6ae554418014e5ddc9b9c22a135cbc863ab0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_6e8828a5bb8f4fb8004ad114ad2e6ae554418014e5ddc9b9c22a135cbc863ab0->leave($__internal_6e8828a5bb8f4fb8004ad114ad2e6ae554418014e5ddc9b9c22a135cbc863ab0_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_7cf64009fae8ee899badffaf35dc3a5706b18833afdbd3be6599ebadd49f02a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7cf64009fae8ee899badffaf35dc3a5706b18833afdbd3be6599ebadd49f02a8->enter($__internal_7cf64009fae8ee899badffaf35dc3a5706b18833afdbd3be6599ebadd49f02a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_7cf64009fae8ee899badffaf35dc3a5706b18833afdbd3be6599ebadd49f02a8->leave($__internal_7cf64009fae8ee899badffaf35dc3a5706b18833afdbd3be6599ebadd49f02a8_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_dcaa10e1048ae3fd9de8a9f8f1686ea0245ea06acda177400c7c6551867d05b0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_dcaa10e1048ae3fd9de8a9f8f1686ea0245ea06acda177400c7c6551867d05b0->enter($__internal_dcaa10e1048ae3fd9de8a9f8f1686ea0245ea06acda177400c7c6551867d05b0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpKernelExtension')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_dcaa10e1048ae3fd9de8a9f8f1686ea0245ea06acda177400c7c6551867d05b0->leave($__internal_dcaa10e1048ae3fd9de8a9f8f1686ea0245ea06acda177400c7c6551867d05b0_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
";
    }
}

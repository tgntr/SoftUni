<?php

/* @Twig/Exception/exception_full.html.twig */
class __TwigTemplate_4b1fb85296f281ee844daf82cdc1e4ab1b4cb0882c049f8dad3d7b1509203d1b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "@Twig/Exception/exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13aa830281f4c7586818e8db894ef8a1e4b85902b6e4996d7e148c28e6f5ebc8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_13aa830281f4c7586818e8db894ef8a1e4b85902b6e4996d7e148c28e6f5ebc8->enter($__internal_13aa830281f4c7586818e8db894ef8a1e4b85902b6e4996d7e148c28e6f5ebc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13aa830281f4c7586818e8db894ef8a1e4b85902b6e4996d7e148c28e6f5ebc8->leave($__internal_13aa830281f4c7586818e8db894ef8a1e4b85902b6e4996d7e148c28e6f5ebc8_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8785311f6ae57759b5b22dcc52c1549daceafe0cee7d680943dc160280420a28 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8785311f6ae57759b5b22dcc52c1549daceafe0cee7d680943dc160280420a28->enter($__internal_8785311f6ae57759b5b22dcc52c1549daceafe0cee7d680943dc160280420a28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\HttpFoundationExtension')->generateAbsoluteUrl($this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_8785311f6ae57759b5b22dcc52c1549daceafe0cee7d680943dc160280420a28->leave($__internal_8785311f6ae57759b5b22dcc52c1549daceafe0cee7d680943dc160280420a28_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_45899ada715f75753a3d6e9d566785c4b48c80a81c563233c4e526332ef13da9 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45899ada715f75753a3d6e9d566785c4b48c80a81c563233c4e526332ef13da9->enter($__internal_45899ada715f75753a3d6e9d566785c4b48c80a81c563233c4e526332ef13da9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_45899ada715f75753a3d6e9d566785c4b48c80a81c563233c4e526332ef13da9->leave($__internal_45899ada715f75753a3d6e9d566785c4b48c80a81c563233c4e526332ef13da9_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_190f8b92be6a0978424ed05d5b402a75274341cada4f4621cc2971d50c29f440 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_190f8b92be6a0978424ed05d5b402a75274341cada4f4621cc2971d50c29f440->enter($__internal_190f8b92be6a0978424ed05d5b402a75274341cada4f4621cc2971d50c29f440_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "@Twig/Exception/exception_full.html.twig", 12)->display($context);
        
        $__internal_190f8b92be6a0978424ed05d5b402a75274341cada4f4621cc2971d50c29f440->leave($__internal_190f8b92be6a0978424ed05d5b402a75274341cada4f4621cc2971d50c29f440_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }

    public function getSource()
    {
        return "{% extends '@Twig/layout.html.twig' %}

{% block head %}
    <link href=\"{{ absolute_url(asset('bundles/framework/css/exception.css')) }}\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
{% endblock %}

{% block title %}
    {{ exception.message }} ({{ status_code }} {{ status_text }})
{% endblock %}

{% block body %}
    {% include '@Twig/Exception/exception.html.twig' %}
{% endblock %}
";
    }
}

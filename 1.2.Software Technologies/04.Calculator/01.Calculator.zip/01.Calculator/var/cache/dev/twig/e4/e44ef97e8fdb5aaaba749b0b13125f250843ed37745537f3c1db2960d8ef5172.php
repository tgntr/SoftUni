<?php

/* form/fields.html.twig */
class __TwigTemplate_8d61cb20313c1217ee2c766888f662d9b4c23d2fda17fda740083fff2ce0ca16 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'date_time_picker_widget' => array($this, 'block_date_time_picker_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_2c5ee6250aac4a05908a6d94ae47ecfcf4407256323dd6e7da6a98e988d4959e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2c5ee6250aac4a05908a6d94ae47ecfcf4407256323dd6e7da6a98e988d4959e->enter($__internal_2c5ee6250aac4a05908a6d94ae47ecfcf4407256323dd6e7da6a98e988d4959e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "form/fields.html.twig"));

        // line 9
        echo "
";
        // line 10
        $this->displayBlock('date_time_picker_widget', $context, $blocks);
        
        $__internal_2c5ee6250aac4a05908a6d94ae47ecfcf4407256323dd6e7da6a98e988d4959e->leave($__internal_2c5ee6250aac4a05908a6d94ae47ecfcf4407256323dd6e7da6a98e988d4959e_prof);

    }

    public function block_date_time_picker_widget($context, array $blocks = array())
    {
        $__internal_d901c4d2da3cbb0edbeed71ca035cb7da5cade9768809f1176ef1bb4df006533 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d901c4d2da3cbb0edbeed71ca035cb7da5cade9768809f1176ef1bb4df006533->enter($__internal_d901c4d2da3cbb0edbeed71ca035cb7da5cade9768809f1176ef1bb4df006533_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "date_time_picker_widget"));

        // line 11
        echo "    ";
        ob_start();
        // line 12
        echo "        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            ";
        // line 13
        $this->displayBlock("datetime_widget", $context, $blocks);
        echo "
            ";
        // line 15
        echo "                ";
        // line 16
        echo "            ";
        // line 17
        echo "        </div>
    ";
        echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        
        $__internal_d901c4d2da3cbb0edbeed71ca035cb7da5cade9768809f1176ef1bb4df006533->leave($__internal_d901c4d2da3cbb0edbeed71ca035cb7da5cade9768809f1176ef1bb4df006533_prof);

    }

    public function getTemplateName()
    {
        return "form/fields.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  52 => 17,  50 => 16,  48 => 15,  44 => 13,  41 => 12,  38 => 11,  26 => 10,  23 => 9,);
    }

    public function getSource()
    {
        return "{#
   Each field type is rendered by a template fragment, which is determined
   by the name of your form type class (DateTimePickerType -> date_time_picker)
   and the suffix \"_widget\". This can be controlled by overriding getBlockPrefix()
   in DateTimePickerType.

   See http://symfony.com/doc/current/cookbook/form/create_custom_field_type.html#creating-a-template-for-the-field
#}

{% block date_time_picker_widget %}
    {% spaceless %}
        <div class=\"input-group date\" data-toggle=\"datetimepicker\">
            {{ block('datetime_widget') }}
            {#<span class=\"input-group-addon\">#}
                {#<span class=\"fa fa-calendar\" aria-hidden=\"true\"></span>#}
            {#</span>#}
        </div>
    {% endspaceless %}
{% endblock %}
";
    }
}
